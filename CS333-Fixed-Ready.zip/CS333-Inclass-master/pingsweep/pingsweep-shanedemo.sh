#!/bin/bash

echo "BOOM!"
